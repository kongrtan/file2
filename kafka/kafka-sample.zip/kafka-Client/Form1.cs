﻿using Confluent.Kafka;
using Hyunsoft.Model;
using System;
using System.Globalization;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace kafka_Client {
	public partial class MainForm : Form {

		private readonly IProducer<Null, string> _producer;

		public MainForm() {
			var config = new ProducerConfig {
				BootstrapServers = "192.168.56.103:9092",
				LingerMs = 5,           // 실시간성 유지
				BatchSize = 32 * 1024   // 32KB
			};

			_producer = new ProducerBuilder<Null, string>(config).Build();

			InitializeComponent();
		}

		private void btnStart_Click(object sender, EventArgs e) {
			Task.Run(() => insertRealData());
		}


		private async Task insertRealData() {

			int counter = 0;
			string line;
			int currHour = DateTime.Now.Hour;
			string[] list = new string[] { 
							"2025-09-11_10081.txt"
							 };
			for (int i = 0; i < list.Length; i++) {
				string filename = string.Format(@"D:\kw_data\{0}", list[i]);
				System.IO.StreamReader file = new System.IO.StreamReader(filename);
				Console.WriteLine(string.Format("{0} Read Complete.", filename));

				bool isWrite = false;

				while ((line = file.ReadLine()) != null) {
					//System.//LOGGER.DEBUG(line);

					string[] spdata = line.Split('\t');

					if (spdata.Length == 25 || spdata.Length == 26) {

						try {
							ChartDayVo chartDayVo = new ChartDayVo();
							DateTime dateTime = DateTime.ParseExact(spdata[1], "yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
							//dateTime = dateTime.AddDays(1);
							chartDayVo.regDt = dateTime;
							chartDayVo.stockCd = spdata[2];
							chartDayVo.hhmmss = spdata[3];
							chartDayVo.currPrc = int.Parse(spdata[4]);
							chartDayVo.fid11 = int.Parse(spdata[5]);
							chartDayVo.fid12 = double.Parse(spdata[6]);
							chartDayVo.fid27 = int.Parse(spdata[7]);
							chartDayVo.fid28 = int.Parse(spdata[8]);
							chartDayVo.fid15 = long.Parse(spdata[9]);
							chartDayVo.accStockVol = int.Parse(spdata[10]);
							chartDayVo.accTransPrc = int.Parse(spdata[11]);
							chartDayVo.startPrc = int.Parse(spdata[12]);
							chartDayVo.highPrc = int.Parse(spdata[13]);
							chartDayVo.lowPrc = int.Parse(spdata[14]);
							chartDayVo.fid25 = spdata[15];
							chartDayVo.fid26 = int.Parse(spdata[16]);
							chartDayVo.fid29 = long.Parse(spdata[17]);
							chartDayVo.fid30 = double.Parse(spdata[18]);
							chartDayVo.fid31 = double.Parse(spdata[19]);
							chartDayVo.fid32 = int.Parse(spdata[20]);
							chartDayVo.fid228 = double.Parse(spdata[21]);
							chartDayVo.fid311 = long.Parse(spdata[22]);
							chartDayVo.fid290 = int.Parse(spdata[23]);
							chartDayVo.fid691 = int.Parse(spdata[24]);

							if (spdata.Length == 26) {
								chartDayVo.exCd = spdata[25];
							}

							var dataTime = DateTime.ParseExact(spdata[1], "yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture);

							int dayDiff = (DateTime.Now.Date - dataTime.Date).Days;

							var adjustedTime = dataTime.AddDays(dayDiff).AddHours(currHour - 8);

							// 초당 전송 속도 맞추기
							var now = DateTime.Now;
							var delay = adjustedTime - now;

							if (delay > TimeSpan.Zero) {
								await Task.Delay(delay);
								isWrite = true;
							}
							if (isWrite) {
								SendKafka(chartDayVo);
							}
						}
						catch (Exception e) {
							Console.WriteLine(e.Message);
							Console.WriteLine(e.StackTrace);
						}


					}
					counter++;


				}

			}
		}




		private void SendKafka(ChartDayVo chartDayVo) {

			string strJson = JsonSerializer.Serialize(chartDayVo);
			string topic = "kw-real-data";

			_producer.Produce(topic,
				new Message<Null, string> { Value = strJson },
				deliveryReport => {
					if (deliveryReport.Error.Code != ErrorCode.NoError) {
						Console.WriteLine("전송 실패: {0}", deliveryReport.Error.Reason);
					}
				});
		}
	}
}
