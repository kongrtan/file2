﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;


namespace Hyunsoft.Model {

	public class ChartDayVo {

		/*
		 * 20 체결시간 (HHMMSS)
			10 현재가, 체결가, 실시간종가
			11 전일 대비
			12 등락율
			27 (최우선)매도호가
			28 (최우선)매수호가
			15 거래량, 체결량
			13 누적거래량, 누적체결량
			14 누적거래대금
			16 시가
			17 고가
			18 저가
			25 전일대비 기호
			26 전일거래량 대비(계약, 주)
			29 거래대금 증감
			30 전일거래량 대비(비율)
			31 거래회전율
			32 거래비용
			228 체결강도
			311 시가총액(억)
			290 장구분
			691 K,O 접근도 (ELW조기종료발생 기준가격, 지수)
		 */

		public DataTable datatable { get; set; }

		public string formulaTp { get; set; }
		public string orderTp { get; set; }
		public int rcmdUid { get; set; }

		public string stockCd { get; set; }
		public string stockNm { get; set; }
		public string hhmmss { get; set; }
		public int currPrc { get; set; }
		public int startPrc { get; set; }
		public int highPrc { get; set; }
		public int lowPrc { get; set; }

		public int avgPrc5 { get; set; }
		public int avgPrc5Ago1 { get; set; }
		public int avgPrc5Ago2 { get; set; }
		public int avgPrc5Ago3 { get; set; }
		public int avgPrc10 { get; set; }
		public int avgPrc20 { get; set; }
		public int avgPrc20Ago1 { get; set; }
		public int avgPrc20Ago2 { get; set; }
		public int avgPrc20Ago3 { get; set; }
		public int avgPrc60 { get; set; }
		public int avgPrc60Ago1 { get; set; }
		public int avgPrc60Ago2 { get; set; }
		public int avgPrc60Ago3 { get; set; }
		public int avgPrc120 { get; set; }
		public int stockUpperLimitPrc { get; set; }
		public double stockPrcPer { get; set; }
		public int stockCurrPrc { get; set; }
		public int fid11 { get; set; }
		public double fid12 { get; set; }
		public int accStockVol { get; set; }
		public int accTransPrc { get; set; }
		public long fid15 { get; set; }
		public string fid25 { get; set; }
		public int fid26 { get; set; }
		public int fid27 { get; set; }
		public int fid28 { get; set; }
		public long fid29 { get; set; }
		public double fid30 { get; set; }
		public double fid31 { get; set; }
		public int fid32 { get; set; }
		public double fid228 { get; set; }
		public double diffFid228 { get; set; }
		public long fid311 { get; set; }
		public int fid290 { get; set; }
		public int fid691 { get; set; }
		public bool isBuy { get; set; }
		//[JsonConverter(typeof(MicrosecondEpochConverter))]
		public DateTime regDt { get; set; }
		public string mediaTp { get; set; }
		public string simulationResult { get; set; }
		public int cnt { get; set; }
		public int stockCnt { get; set; }
		public double highFid12 { get; set; }
		public double envTodayStopHighPer { get; set; }
		public double envTodayStopLossPer { get; set; }
		public int sysTradUid { get; set; }
		public double predictValue { get; set; }
		//20220614 매도호가 및 수량 정보 추가
		public int hogaSellAmtLevel3 { get; set; }

		public string accNo { get; set; }

		public string fid851 { get; set; }	//전일 동시간 거래량 비율
		public string fid1030 { get; set; }	//매도체결량
		public string fid1031 { get; set; }	//매수체결량
		public string fid1032 { get; set; }	//매수비율
		public string fid9081 { get; set; }	//거래소구분

		public string gapType { get; set; }	//갭종류
		public int buyPrc { get; set; }
		public DateTime buyDt { get; set; }

		public string exCd { get; set; }	//거래소
		public string scrNo { get; set; }	//스크린번호
	}
}
