using Microsoft.AspNetCore.SignalR;
using ChatService.Services;

namespace ChatService.Hubs;

public class ChatHub : Hub
{
    private readonly KafkaProducer _producer;
    private readonly IConfiguration _config;

    public ChatHub(KafkaProducer producer, IConfiguration config)
    {
        _producer = producer;
        _config = config;
    }

    public async Task SendMessage(string roomId, string user, string message)
    {
        var topic = _config["Kafka:Topic"] ?? "chat-messages";
        await _producer.PublishMessage(topic, roomId, $"{user}:{message}");
    }

    public override async Task OnConnectedAsync()
    {
        var roomId = Context.GetHttpContext()?.Request.Query["roomId"];
        if (!string.IsNullOrEmpty(roomId))
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, roomId);
        }
        await base.OnConnectedAsync();
    }

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        var roomId = Context.GetHttpContext()?.Request.Query["roomId"];
        if (!string.IsNullOrEmpty(roomId))
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, roomId);
        }
        await base.OnDisconnectedAsync(exception);
    }
}
