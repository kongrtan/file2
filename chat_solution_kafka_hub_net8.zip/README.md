# ChatSolution with Kafka + SignalR (.NET 8)

This sample demonstrates a chat system that works across multiple pods using Kafka as the message backbone.

## How it Works

- Clients connect to SignalR Hub (`/chathub`) and join a room (via query string).
- When a client sends a message:
  - Hub publishes to Kafka (`chat-messages` topic).
- All pods run a Kafka consumer (with unique GroupId per pod).
  - This ensures **every pod receives all messages**.
  - Each pod then broadcasts to its local SignalR clients in that room.
- Result: Even if clients are connected to different pods, they all see the same chat.

## Run

1. Ensure Kafka is running and accessible (`localhost:9092` by default).
2. Run ChatService:
   ```bash
   cd ChatService
   dotnet run
   ```
3. Run ChatClient (Blazor WASM):
   - Serve it (publish and host, or integrate as hosted Blazor project).
4. Open `/chat` in browser, enter a name and message.

## Scaling

- Deploy multiple ChatService pods (Kubernetes, Docker Swarm, etc.).
- Each pod connects to Kafka with its own consumer group id (unique).
- Kafka guarantees message delivery to all pods, enabling cross-pod SignalR broadcast.

