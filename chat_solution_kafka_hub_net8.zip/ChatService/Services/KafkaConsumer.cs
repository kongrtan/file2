using Confluent.Kafka;
using Microsoft.AspNetCore.SignalR;
using ChatService.Hubs;

namespace ChatService.Services;

public class KafkaConsumer : BackgroundService
{
    private readonly IConsumer<string, string> _consumer;
    private readonly IHubContext<ChatHub> _hubContext;
    private readonly string _topic;

    public KafkaConsumer(IConfiguration config, IHubContext<ChatHub> hubContext)
    {
        _hubContext = hubContext;
        _topic = config["Kafka:Topic"] ?? "chat-messages";

        var consumerConfig = new ConsumerConfig
        {
            BootstrapServers = config["Kafka:BootstrapServers"] ?? "localhost:9092",
            GroupId = $"chat-service-{Guid.NewGuid()}",
            AutoOffsetReset = AutoOffsetReset.Earliest,
            EnableAutoCommit = true
        };

        _consumer = new ConsumerBuilder<string, string>(consumerConfig).Build();
        _consumer.Subscribe(_topic);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    var cr = _consumer.Consume(stoppingToken);
                    if (cr?.Message != null)
                    {
                        var roomId = cr.Message.Key ?? "default";
                        var value = cr.Message.Value ?? string.Empty;

                        var parts = value.Split(":", 2);
                        var user = parts.Length > 1 ? parts[0] : "system";
                        var msg = parts.Length > 1 ? parts[1] : value;

                        await _hubContext.Clients.Group(roomId).SendAsync("ReceiveMessage", user, msg);
                    }
                }
                catch (ConsumeException ex)
                {
                    Console.WriteLine($"Consume error: {ex.Error.Reason}");
                }
            }
        }
        finally
        {
            _consumer.Close();
        }
    }
}
