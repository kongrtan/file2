using ChatService.Hubs;
using ChatService.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSignalR();
builder.Services.AddSingleton<KafkaProducer>();
builder.Services.AddHostedService<KafkaConsumer>();

var app = builder.Build();

app.MapHub<ChatHub>("/chathub");

app.Run();
